<?php 
/**
 * Inluding Plugins
 *
 * @author Azfar Ahmed
 * @version 1.0
 * @date November 02, 2015
 * @EasyPhp MVC Framework
 * @website www.tutbuzz.com
 */
 
 /*
 How to add plugins to main function?
 - Just add php code to include the plugin file, Ex: include("plugins/FolderName/Filename.php");
 */
 
 /* valitron - form validation plugin */
 include("plugins/valitron-master/src/Valitron/Validator.php"); //uncomment this
 
 ?>
 
 