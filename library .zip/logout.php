<?php
@ session_start();

	session_destroy();
	unset($_SESSION["std_admin"]);
	header("location: login.php");
	exit();
	
?>