<?php


define("DB_HOST", "localhost"); //write your host
define("DB_USER", "root"); //write your db username
define("DB_PASSWORD", ""); //write your db password
define("DB_DATABASE", "blms"); //write your database name
 @ $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);

?>
