$(window).scroll(function() {
    var scroll = $(window).scrollTop();    
    if (scroll >= 750) {
        $(".cta").removeClass("hidee").addClass("showw");
    }
    else {
    	$(".cta").removeClass("showw").addClass("hidee");
    }   

	
});
$(document).ready(function() {
	$('.cta').click(function (e) {
		e.preventDefault();
			$("html, body").animate({
				scrollTop: 0
			}, 500);
			return false;
	});
});