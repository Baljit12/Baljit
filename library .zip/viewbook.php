

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
    <title>Library Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href="css/clean-blog.min.css" rel="stylesheet">
 
  </head>

  <body>

  <?php
    include('include/config.php');
	 $id=$_GET['book'];
  @ session_start();
  include('nav.php');
 

  ?>
    <?php

   $sql=mysqli_query($conn,"SELECT * FROM books  WHERE id='$id' ");
   $row=mysqli_fetch_assoc($sql);
   $img=(empty($row['image'])? 'cover_default.jpg' : $row['image']);

 
	
	
   ?>
    <!-- Page Header -->
    <header class="masthead" style="background-image: url('img/home-bg.jpg')">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="site-heading">
              <h1>LMS</h1>
              <span class="subheading">Registration</span>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Main Content -->
    <div class="container">
	<div class="row">
		<div class="col-xs-12 own">
			<center><strong class="text-info" style="font-family:'Cooper Black'; font-size:20px"><i class="fa fa-book"></i> Details - Book</strong></center>
		</div>
	</div>
	<br>
	<!-- setting variables -->
	<div class="row">

		 <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12 text-center">
		    
			<img class="img img-thumbnail" style="width:250px; height:320px" src="uploads/<?php echo $img ?>">
			
			 <h3 class="text-center" style="font-family:'Cooper Black'"> <?php echo $row['title'] ?></h3>
			
			<?php
			
			if(!empty($_SESSION["std_admin"])){
				$session_id=$_SESSION["std_id"];
			$sqlz=mysqli_query($conn,"SELECT * FROM bookrequest  WHERE book_id='$_GET[book]' AND std_id='$session_id' ");
			$c=mysqli_num_rows($sqlz);
			if($c > 0){
			echo '<h5 class="text-center gray">Request Successful </h5>';
			}
		else{			
			?>
			<h5 class="text-center gray"> <button class="btn btn-info " id="request"> Request </button> </h5> 
			
			<input type="hidden" id="stdid" value="<?php echo $session_id ?>">
			<input type="hidden" id="the_book" value="<?php echo $_GET['book'] ?>">
		
			<?php
		}
			}
			else{
				echo '<h5 class="text-center gray"><a href="login.php" > Please Login For Request</a> </h5>' ;
			}
			?>
		</div> 

		<div class="col-md-9 col-lg-9 col-sm-12 col-xs-12">

			<div>

				<!-- Nav tabs -->
				<ul class="nav nav-tabs" role="tablist">
					<li role="presentation" class=""><a href="#home" aria-controls="home" role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-th-large"></i> Basic info</a></li>
					

				</ul>

				<!--tab one -->

				<div class="tab-content">
					<div role="tabpanel" class="tab-pane active" id="home">

						<div class="row">

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> ISBN</p>
									<footer> <?php echo $row['isbn'] ?></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Title</p>
									<footer> <?php echo $row['title'] ?></footer>
								</blockquote>
							</div>

											

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p>
										<i class="fa fa-circle-o">
										</i>  
										Author									</p>
									<footer><?php echo $row['author'] ?></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Edition </p>
									<footer><?php echo $row['edition'] ?></footer>
								</blockquote>
							</div>
						
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p>
										<i class="fa fa-circle-o">
										</i>  
										Publisher									</p>
									<footer><?php echo $row['publisher'] ?></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Edition </p>
									<footer><?php echo $row['edition'] ?></footer>
								</blockquote>
							</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p>
										<i class="fa fa-circle-o">
										</i>  
										Price									</p>
									<footer><?php echo $row['price'] ?></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Total Copy </p>
									<footer><?php echo $row['total_copy'] ?></footer>
								</blockquote>
							</div>
						
							

							
							
						</div> <!-- end row -->
					</div>	<!-- end tab panel -->					

					<!-- tab one close -->

					<!-- tab 2 start -->

					<div role="tabpanel" class="tab-pane " id="profile">						

						<div class="row">

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Physical Form </p>
									<footer></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p>
										<i class="fa  fa-circle-o">
										</i> 
										Editor									</p>
									<footer></footer>
								</blockquote>
							</div>

							

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p>
									<i class="fa fa-circle-o">
									</i> 
									Total Pages</p>
									<footer>0									</footer>
								</blockquote>
							</div>


							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Size</p>
									<footer>Medium</footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Series</p>
									<footer></footer>
								</blockquote>
							</div>							

							<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
								<blockquote>
									<p>
										<i class="fa fa-circle-o">
										</i> 
										Price										</p>
										<footer>
																					</footer>
									</blockquote>
								</div>
								<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
									<blockquote>
										<p>
											<i class="fa fa-circle-o">
											</i> 
											Location</p>
											<footer>
												stack 2 nd floor											</footer>
										</blockquote>
								</div>

								<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p>
										<i class="fa  fa-th-circle-o">
										</i> 
										Clue Page									</p>
									<footer></footer>
								</blockquote>
							</div>

					

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Publisher</p>
									<footer></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
								<blockquote>
									<p>
										<i class="fa fa-circle-o">
										</i> 
										Publication Year - Place</p>
										<footer>0000 - </footer>
								</blockquote>
							</div>
													
							
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p>
									<i class="fa fa-circle-o">
									</i> 
									Source of Book</p>
									<footer>									</footer>
								</blockquote>
							</div>
							</div> 

					</div>
					<!-- tab 2 closes -->
				</div> <!-- end tab content -->
			</div>
		</div>
	</div>
</div>
	
	 <footer id="footerz">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <ul class="list-inline text-center">
              <li class="list-inline-item">
                <a href="#">
                  <span class="fa-stack fa-lg">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-twitter fa-stack-1x fa-inverse"></i>
                  </span>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <span class="fa-stack fa-lg">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-facebook fa-stack-1x fa-inverse"></i>
                  </span>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <span class="fa-stack fa-lg">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-github fa-stack-1x fa-inverse"></i>
                  </span>
                </a>
              </li>
            </ul>
            <p class="copyright text-muted">Copyright Baljit Kaur &copy; Library Management System</p>
          </div>
        </div>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

 

			
			<script>

$(document).ready(function(){
	$("#request").click(function (e) {
        e.preventDefault();
       var the_id=$("#stdid").val();
       var the_book=$("#the_book").val();
    
		$.ajax({
				
				url: 'cpresponse.php',
				type: 'POST',
				 data: {book:the_book,std:the_id},
				dataType: 'text',
				success: function(data){
			$(".gray").text(data);
        }
        });
   
    });
	
  })
			</script>
  </body>

</html>

	 