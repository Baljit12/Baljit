<?php

include('../include/config.php');
include_once("session.php");


?>
	<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-type" content="text/html; charset=us-ascii">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Update Password</title>
    <?php 
	include("head.php");
	?>

  </head>
    <body>
	
	  <div id="wrapper">
  <?php
include_once('menu.php');
 
 if(isset($_POST['submit']))
 {
	$sql= mysqli_query($conn,"SELECT * FROM admin WHERE username='admin' ");
	$row=mysqli_fetch_assoc($sql);
	
	$cpass=$_POST['cupass'];    
	$pwd=$_POST['pwd'];	
	$cpwd=$_POST['cpwd'];
	if($cpass != $row['password'] )
	{
		$error="Old Password Is Incorrect";
	}
	elseif($pwd != $cpwd)
	{
		$error="Password Doesn't Match";
	}
	else
	{
		$query =mysqli_query($conn,"UPDATE admin SET password='$pwd' WHERE username='admin' ");
		if($query)
		{
			$error= "Password Updated";
			
		}
		else
		{
			$error="SORRY Password Not Update";
		}
	}
	
 }
  ?>

  <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Update Password</h2>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          Update Password
                        </div>
						
                        <div class="panel-body">
						
				<?php
				
					if(isset($error)){
					echo "<div class='text-center' id='fade'> ";
					echo $error;
					echo "</div>";
					}
					?>
                        
                           <div class="row">
	 
<form class="form-horizontal" method="post">
<fieldset>

<!-- Form Name -->


<!-- Password input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="piCurrPass"> Old Password</label>
  <div class="col-md-4">
    <input id="cupass" name="cupass" type="password"  class="form-control input-md" required="">
    
  </div>
</div>

<!-- Password input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="piNewPass">New Password</label>
  <div class="col-md-4">
    <input id="pwd" name="pwd" type="password"  class="form-control input-md" required="">
    
  </div>
</div>

<!-- Password input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="piNewPassRepeat">Confirm Password</label>
  <div class="col-md-4">
    <input id="cpwd" name="cpwd" type="password"  class="form-control input-md" required="">
    
  </div>
</div>


<div class="form-group">
  <label class="col-md-4 control-label" for="bCancel"></label>
  <div class="col-md-4">
   
    <input type="submit" id="change" name="submit" value="Update" class="btn btn-success btn-block">
  </div>
  
</div>

</fieldset>
</form>

</div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    
 
 

</div>
</div>
<?php
include("footer.php");
?>
</body>