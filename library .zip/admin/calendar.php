<?php
  require('../include/config.php');
require("session.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
<title> Calendar</title>
   <?php
   include('head.php');
  
   ?>
<style>
#addcat{
	display:none;
}
.cal{
	background:#f5f5f5;
	padding:10px;
	margin:5px;
}
</style>

  <script type="text/javascript" src="http://www.google.com/jsapi"></script>
 <link href="http://www.google.com/uds/modules/elements/transliteration/api.css"
      type="text/css" rel="stylesheet"/>
    <script type="text/javascript">
      // Load the Google Transliteration API
      google.load("elements", "1", {
            packages: "transliteration"
          });
      function onLoad() {
        var options = {
            sourceLanguage:
                google.elements.transliteration.LanguageCode.ENGLISH,
				destinationLanguage:
             google.elements.transliteration.LanguageCode.HINDI,
            shortcutKey: 'ctrl+g',
            transliterationEnabled: true
        };

        // Create an instance on TransliterationControl with the required
        // options.
        var control =
            new google.elements.transliteration.TransliterationControl(options);

			var ids = [ "title"];
        control.makeTransliteratable(ids);
		
      }
      google.setOnLoadCallback(onLoad);
    </script>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
       <?php
	   include_once("menu.php");
	   
	   if(isset($_POST['addcal'])){
		   $title=$_POST['title'];
		   $date=$_POST['date'];
		   $sqls=mysqli_query($conn,"INSERT INTO calendar(title,date)  VALUES ('$title','$date') ");
		  if($sqls){
			$msg=' <div class="alert alert-success">
    <strong>Success!</strong> New Activity Add.
  </div>';
		}
		else{
			$msg=' <div class="alert alert-danger">
    <strong>Sorry!</strong> Activity Not Add.
  </div>';
		}
	   }
	   ?>
	   
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Calendar</h1>
                </div>
               
            </div>
			
			<?php 
					@session_start() ;
					if(isset($_SESSION['error']))
					{
			echo '<div class="alert alert-warning text-center" id="fade">';
			   echo $_SESSION['error'] ;
				   unset($_SESSION['error']);
				   echo '</div>';
						
				
					}
					?><?php 
					
					if(isset($msg))
					{
			echo '<div  id="fade">';
			   echo $msg ;
				 
				   echo '</div>';
						
				
					}
					?>
            <!-- /.row -->
				<button id="addnew" class="btn btn-success">Add New Activity </button>
				
				<div class="col-lg-12 text-center cal" id="addcat">
				<h1>Add New Activity <h1>
		<form class="form-inline" method="post">
  <div class="form-group">
 
    <input type="text" class="form-control" id="title"  name="title" placeholder="Activity Name">
  </div>
  <div class="form-group">
 
    <input class="form-control" id="date" name="date" placeholder="YYYY/MM/DD" type="text"/>
  </div>
  
  <input type="submit" class="btn btn-success" name="addcal" value="Submit">
  <a href="calendar.php" class="btn btn-danger"  >Cancel </a>
</form>
		</div>		
				<br> <br>
				
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Manage Activity Calendar 
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                       
                                        <th>Title</th>
										<th>Date</th>
										<th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
								
					<?php
				
				$sql=mysqli_query($conn,"SELECT * FROM calendar LIMIT  300");
				while ($row=mysqli_fetch_assoc($sql) )
				{
			
				
				?>
								
                             <tr class="odd gradeX">
                                      
                             <td><?php echo $row['title'];  ?></td>
						  <td><?php echo $row['date'];  ?></td>
                   
                          
                                <td class="center"><a href="delete.php?activity=<?php echo $row['id'] ?> " onclick="return confirm('Are you sure you want to delete this category?');" class="btn btn-danger"> Delete </a></td>
                                    </tr>
                                   <?php
					}
				
				?>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                         
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
           
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
          
   
  <?php
  include_once('footer.php');
  ?>

   <script type="text/javascript" src="js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="css/bootstrap-datepicker3.css"/>
    <script>

    $(document).ready(function() {
		var date_input=$('input[name="date"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'yyyy/mm/dd',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
		
        $('#dataTables-example').DataTable({
            responsive: true,
			"order": [[ 1, "desc" ]]
        });
    });
    </script>
<script type="text/javascript">
	$(document).ready(function(){
  
      $("#fade").fadeOut(6000);
	  $("#addcat").hide();
	  
	  $("#addnew").click(function(){
		$(this).hide();
		$("#addcat").show();
	 
	  });
   
});
	</script>
</body>

</html>
