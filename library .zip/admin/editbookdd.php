<?php
  require('../include/config.php');
require("session.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

 

    <title>Update Member</title>

   <?php
   include('head.php');
	$ID=$_GET['member'];
	$select=mysqli_query($conn,"SELECT * FROM members WHERE id='$ID' ");
	$rowz=mysqli_fetch_assoc($select);
   ?>

</head>

<body>

    <div id="wrapper">

      <?php
   include_once('menu.php');

	if(isset($_POST['submit'])){
	
	$name=$_POST['name'];
	$contact=$_POST['contact'];
	$city=$_POST['city'];
	$address=$_POST['address'];
	$father=$_POST['fathername'];
	$category=$_POST['category'];
		
		if(!empty($_FILES['stdimage']['name'])){
				$tmpname = $_FILES['stdimage']['tmp_name'];	
				$path = "../uploads/members/";
			 $ext = $_FILES['stdimage']['name'];
            $filetype = pathinfo($ext, PATHINFO_EXTENSION);
			$filetype=strtolower($filetype);
            $unique_name = (uniqid(rand(), true)) . "." . $filetype;
			move_uploaded_file($tmpname, $path."/".$unique_name);
			$sqls=mysqli_query($conn,"UPDATE members SET name='$name',father_name='$father' ,phone='$contact', image='$unique_name',city='$city' ,address='$address',category='$category' WHERE id='$ID' LIMIT 1 ");
		}
		else{
				$sqls=mysqli_query($conn,"UPDATE members SET name='$name',father_name='$father' ,phone='$contact', city='$city' ,address='$address',category='$category' WHERE id='$ID' LIMIT 1 ");
		}
		if($sqls){
			$msg=' <div class="alert alert-success">
    <strong>Success! </strong>Member Update.
  </div>';
		}
		else{
			$msg=' <div class="alert alert-danger">
    <strong>Sorry!  </strong> Member Not Update.
  </div>';
		}
	}
		
	
	
   ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Update Member</h2>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          Update Member
                        </div>
						
                        <div class="panel-body">
						
					<?php
				
					if(isset($msg)){
					echo "<div class='text-center' id='fade'> ";
					echo $msg;
					echo "</div>";
					}
					?>
                           <div class="row">
	     <form method="post" enctype="multipart/form-data">
        <div class="col-md-8 col-md-offset-2">
		<h1 class="text-center">Add New Member </h1>
		<br>
		<div class="form-group">
		<label> Name:</label>
	<input class="form-control" id="name" name="name" type="text" value="<?php echo $rowz['name']; ?>"  required>
	</div>
	
	<div class="form-group">
		<label> Father Name:</label>
	<input class="form-control" name="fathername" id="fathername" type="text" value="<?php echo $rowz['father_name']; ?>" >
	</div>
		<div class="form-group">
		<label> Contact:</label>
	<input class="form-control" id="contact" name="contact" type="text" value="<?php echo $rowz['phone']; ?>" required >
	</div>

	<div class="form-group">
		<label> City:</label>
	<input class="form-control" id="city" name="city" type="text" value="<?php echo $rowz['city']; ?>" required >
	</div>

	<div class="form-group">
		<label> Address :</label>
	<textarea class="form-control" name="address" id="address" rows="3"  required ><?php echo $rowz['address']; ?></textarea>
	</div>
	
	<div class="form-group">
		<label> Category:</label>
	 <select  name="category" id="category"  class="form-control" required>
				 <?php
				 $q=mysqli_query($conn,"SELECT * FROM category ");
				
				  while($r=mysqli_fetch_assoc($q))
				  {
					 
					  $catname=$r['cat_name'];
					 if($rowz['category'] == $catname ){
					
						$n="selected";	
					 }
					 else{
					 $n="";
					 }

					 echo "<option value='$catname' $n> $catname</option>";
				  }
				  ?>
                  
                </select>
	</div>
	 <div class="imageupload panel panel-info">
                <div class="panel-heading clearfix">
                    <h3 class="panel-title pull-left">Upload Image</h3>
                   
                </div>
                <div class="file-tab panel-body">
                    
                       
                     <div class="form-group">
					<p>Please Choose Image: </p>
					<input type="file" name="stdimage" >
					<span class="help-block"></span>
				</div>
                   
                   
                </div>
               
            </div>
			
	
			<div class="col-md-12">
       <input type="submit" class="btn btn-success pull-right"  name="submit" value="Update">
	   </div>
		
		
		  </div>
		  </form>  </div>
                            <!-- row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                 <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    
   
  <?php
 
  include_once('footer.php');
  ?>

	<script type="text/javascript">
	$(document).ready(function(){
  
      $("#fade").fadeOut(6000);
	  var url=$("#category").find('option:selected').val();
   	 if(fade != ''){
		$("#fade").fadeOut(1500);
	  window.setTimeout(function() {
    window.location.href = 'members.php?catname='+url;
}, 1000);
	 }
});
	</script>
</body>

</html>
