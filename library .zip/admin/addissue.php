<?php
  require('../include/config.php');
require("session.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

 

    <title>Issue New Book</title>

   <?php
  include('head.php');
 

   ?>
 <link href="vendor/datepicker/datepicker3.css" rel="stylesheet">  

</head>

<body>

    <div id="wrapper">

      <?php
  include_once('menu.php');

	
	if(isset($_POST['submit'])){
	
	$book_id=$_POST['book_id'];
	$student_id=$_POST['student_id'];
	$description=mysqli_real_escape_string($conn, $_POST['description']);
	$from=$_POST['from'];
	$to=$_POST['to'];
		
	
				$sqls=mysqli_query($conn,"INSERT INTO book_issue(book_id, student_id, description, from_date, to_date,is_return) VALUES ('$book_id','$student_id','$description','$from','$to','0')");
		
		if($sqls){
			$msg=' <div class="alert alert-success">
    <strong>Success! </strong>Book Issue .
  </div>';
		}
		else{
			$msg=' <div class="alert alert-danger">
    <strong>Sorry! </strong> Book Not Issue.
  </div>';
		}
	}
		
	
	
   ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Issue New Book</h2>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row" >
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Issue New Book
                        </div>
						
                        <div class="panel-body">
						
					<?php
				
					if(isset($msg)){
					echo "<div class='text-center' id='fade'> ";
					echo $msg;
					echo "</div>";
					}
					?>
                           <div class="row"> 
	     <form method="post" enctype="multipart/form-data" >
        <div class="col-md-8 col-md-offset-2">
		<h1 class="text-center"> Issue Book </h1>
		<br>
		
	<div class="form-group">
		<label> Book:</label>
	 <select  name="book_id" id="book_id"  class="form-control" required>
				 <?php
				 $q=mysqli_query($conn,"SELECT * FROM books ORDER BY title ASC");
				
				  while($r=mysqli_fetch_assoc($q))
				  {
					  
					   $catname=$r['title'];
					   $bid=$r['id'];
					  echo "<option value='$bid'> $catname</option>";
				  }
				  ?>
                  
                </select>
	</div>
	
	<div class="form-group">
		<label> Student:</label>
	 <select  name="student_id" id="student_id"  class="form-control" required>
				 <?php
				 $q=mysqli_query($conn,"SELECT * FROM students ");
				
				  while($r=mysqli_fetch_assoc($q))
				  {
					  
					  $catname=$r['name'];
					  $sid=$r['id'];
					  echo "<option value='$sid'> $catname</option>";
				  }
				  ?>
                  
                </select>
	</div>
	<div class="form-group">
		<label> Description :</label>
	<textarea class="form-control"  name="description" rows="3"> </textarea>
	</div>
	
	<div class="form-group">
		<label> From :</label>
	<input class="form-control" id="from" name="from" type="text"   required>
	</div>
	
	<div class="form-group">
		<label> To :</label>
	<input class="form-control" id="to" name="to" type="text"   required>
	</div>
	
			<div class="col-md-12 ">
       <input type="submit" class="btn btn-success pull-right"  name="submit" value="Submit">
	   </div>
		
		
		  </div>
		  </form>  </div>
                            <!-- /.row  -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </;div>
        <!-- /#page-wrapper -->

    </div>
    
   
  <?php
 
  include_once('footer.php');
  ?>

 <script src="vendor/datepicker/bootstrap-datepicker.js"></script> 
<script>
	 $('#from').datepicker({
			  format: "yyyy-mm-dd",
					autoclose: true
     
    });
	
	 $('#to').datepicker({
			  format: "yyyy-mm-dd",
					autoclose: true
     
    });
	
			</script>
</body>

</html>
