<?php
  require('../include/config.php');
require("session.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

 

    <title>Add Book</title>

   <?php
   include('head.php');
 

   ?>

</head>

<body>

    <div id="wrapper">

      <?php
   include_once('menu.php');


	if(isset($_POST['submit'])){
	
	$title=$_POST['title'];
	$author=$_POST['author'];
	$publisher=$_POST['publisher'];
	$edition=$_POST['edition'];
	$isbn=$_POST['isbn'];
	$price=$_POST['price'];
	$total_copy=$_POST['total_copy'];
		
	
				$sqls=mysqli_query($conn,"INSERT INTO books(title, author, publisher, edition, isbn, price, total_copy) VALUES  ('$title','$author','$publisher','$edition','$isbn','$price','$total_copy') ");
	
		if($sqls){
			$msg=' <div class="alert alert-success">
    <strong>Success! </strong> New Book Add .
  </div>';
		}
		else{
			$msg=' <div class="alert alert-danger">
    <strong>Sorry! </strong> Book Not Add.
  </div>';
		}
	}
		
	
	
   ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Add New Book</h2>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          Add New Book
                        </div>
						
                        <div class="panel-body">
						
					<?php
				
					if(isset($msg)){
					echo "<div class='text-center' id='fade'> ";
					echo $msg;
					echo "</div>";
					}
					?>
                           <div class="row">
	     <form method="post" enctype="multipart/form-data">
        <div class="col-md-8 col-md-offset-2">
		<h1 class="text-center">Add New Book </h1>
		<br>
		<div class="form-group">
		<label> Title:</label>
	<input class="form-control" id="title" name="title" type="text"   required>
	</div>
	
	<div class="form-group">
		<label> Author Name:</label>
	<input class="form-control" name="author" id="author" type="text"   required>
	</div>
		<div class="form-group">
		<label> Publisher:</label>
	<input class="form-control" id="publisher" name="publisher" type="text"  required >
	</div>

	<div class="form-group">
		<label> Edition:</label>
	<input class="form-control" id="edition" name="edition" type="text"   >
	</div>

	<div class="form-group">
		<label> ISBN:</label>
	<input class="form-control" id="isbn" name="isbn" type="text"   >
	</div>
	
	<div class="form-group">
		<label> Price:</label>
	<input class="form-control" id="price" name="price" type="text"   >
	</div>
	
	<div class="form-group">
		<label> Total Copy:</label>
	<input class="form-control" id="total_copy" name="total_copy" type="text"   >
	</div>

	


			
	
			<div class="col-md-12">
       <input type="submit" class="btn btn-success pull-right"  name="submit" value="Add Book">
	   </div>
		
		
		  </div>
		  </form>  </div>
                            <!-- row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                 <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    
   
  <?php
 
  include_once('footer.php');
  ?>


	<script type="text/javascript">
	$(document).ready(function(){
  $("#name").focus();
      $("#fade").fadeOut(5000);
   
});
	</script>
</body>

</html>
