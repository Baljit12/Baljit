<?php
  require('../include/config.php');
require("session.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

   <?php
   include('head.php');
  
   ?>
 <link rel="stylesheet" type="text/css" href="css/mstyle.css">
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
       <?php
	   include_once("menu.php");
	   ?>
	   
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">User's Posts</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
       
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            User's Unapprove Posts
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                     <div class="market-updates">
					
			
					<?php
				$i=0;
				
				
				$sql=mysqli_query($conn,"SELECT * FROM category LIMIT 8 ");
				while ($row=mysqli_fetch_assoc($sql) )
				{
				$i=++$i;
				if($i==4){
					$i=1;
				}
				$cat=$row['cat_name'];
				
				?>
									
					 
			<div class="col-md-6 market-update-gd">
			<a href="members.php?catname=<?php echo $cat ?>" >
				<div class="market-update-block clr-block-<?php echo $i; ?>">
					<div class="col-md-8 market-update-left">
						<h3><?php $sqls=mysqli_query($conn,"SELECT * FROM members WHERE category ='$cat' ");
	 $number=mysqli_num_rows($sqls); 
	echo $number;
	?> </h3>
						<h4><?php echo $cat; ?></h4>
						<p>&nbsp;</p>
						
					
					</div>
				
				  <div class="clearfix"> </div>
				</div>
				</a>
			</div>
			
		  
		   
		   <?php
				}
		   ?>
		    <div class="clearfix"> </div>
		</div>
                         
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
           
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
          
   
  <?php
  include_once('footer.php');
  ?>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
  
	
<script type="text/javascript">
	$(document).ready(function(){
  
      $("#fade").fadeOut(6000);
   
});
	</script>
</body>

</html>
