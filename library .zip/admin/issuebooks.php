<?php
  require('../include/config.php');
require("session.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
<title>Issue Books</title>
   <?php
   include('head.php');
  
   ?>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
       <?php
	   include_once("menu.php");
	   ?>
	   
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Manage Issue Books</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
          <?php 
					@session_start() ;
					if(isset($_SESSION['error']))
					{
			echo '<div class="alert alert-warning text-center" id="fade">';
			   echo $_SESSION['error'] ;
				   unset($_SESSION['error']);
				   echo '</div>';
						
				
					}
					?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Issue Books
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                       
                                        <th>Book</th>
                                        <th>Student</th>
                                        <th>Issue Date</th>
                                        <th>Return Date</th>
                                        <th>Return</th>
										<th>Action</th>
                                    </tr>
                                </thead>
                               
							   <tbody>
				<?php
				$sql=mysqli_query($conn,"SELECT books.title, students.name , book_issue.* FROM `book_issue` INNER JOIN books ON book_issue.book_id=books.id INNER JOIN students ON book_issue.student_id = students.id");
				
				while($row=mysqli_fetch_assoc($sql)){
					$id=$row['id'];
				?>
                <tr>
                  <td> <?php echo $row['title'];  ?> </td>
                  <td> <?php echo $row['name'];  ?> </td>
                  <td> <?php echo $row['from_date'];  ?> </td>
                  <td> <?php echo $row['to_date'];  ?> </td>
                  <td> <?php echo ($row['is_return']=='0' ? 'No' : 'Yes') ;  ?> </td>
                  <td class="view">
				  <a title="Return" style="cursor:pointer" href="viewbook.php?book=<?php echo $id ?>" onclick="return confirm('Are you sure you want to return this ?');"> <img src="img/return.png" alt="Return"></a> </td>
                 
                  
                </tr>
               <?php
				}
				?>
                
               
               
                </tbody>
                            </table>
                          
                         
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
           
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
          
   
  <?php
  include_once('footer.php');
  ?>

 
<script type="text/javascript">
	$(document).ready(function(){
  
    $('#dataTables-example').DataTable();

      $("#fade").fadeOut(6000);
  
});
	</script>

</body>

</html>
