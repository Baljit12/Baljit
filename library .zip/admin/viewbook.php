<?php
  require('../include/config.php');
require("session.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

 

    <title>View Book Details</title>

   <?php
   include('head.php');
 
   $id=$_GET['book'];
    
   ?>

</head>

<body>

    <div id="wrapper">

      <?php
   include_once('menu.php');
   $sql=mysqli_query($conn,"SELECT * FROM books  WHERE id='$id' ");
   $row=mysqli_fetch_assoc($sql);
   $img=(empty($row['image'])? 'cover_default.jpg' : $row['image']);
	
	
	
   ?>

        <div id="page-wrapper">
          
            <!-- /.row -->
         <div class="container-fluid">
	<div class="row">
		<div class="col-xs-12 own">
			<center><strong class="text-info" style="font-family:'Cooper Black'; font-size:20px"><i class="fa fa-book"></i> Details - Book</strong></center>
		</div>
	</div>
	<br>
	<!-- setting variables -->
	<div class="row">

		 <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12 text-center">
		    
			<img class="img img-thumbnail" style="width:250px; height:320px" src="../uploads/<?php echo $img ?>">
			
			 <h3 class="text-center" style="font-family:'Cooper Black'"> <?php echo $row['title'] ?></h3>
			<h4 class="text-center gray"> </h4> 
			
			 
			<h4 class="text-center"> <span class="label label-success">Available</span></h4> 

		</div> 

		<div class="col-md-9 col-lg-9 col-sm-12 col-xs-12">

			<div>

				<!-- Nav tabs -->
				<ul class="nav nav-tabs" role="tablist">
					<li role="presentation" class=""><a href="#home" aria-controls="home" role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-th-large"></i> Basic info</a></li>
					

				</ul>

				<!--tab one -->

				<div class="tab-content">
					<div role="tabpanel" class="tab-pane active" id="home">

						<div class="row">

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> ISBN</p>
									<footer> <?php echo $row['isbn'] ?></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Title</p>
									<footer> <?php echo $row['title'] ?></footer>
								</blockquote>
							</div>

											

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p>
										<i class="fa fa-circle-o">
										</i>  
										Author									</p>
									<footer><?php echo $row['author'] ?></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Edition </p>
									<footer><?php echo $row['edition'] ?></footer>
								</blockquote>
							</div>
						
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p>
										<i class="fa fa-circle-o">
										</i>  
										Publisher									</p>
									<footer><?php echo $row['publisher'] ?></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Edition </p>
									<footer><?php echo $row['edition'] ?></footer>
								</blockquote>
							</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p>
										<i class="fa fa-circle-o">
										</i>  
										Price									</p>
									<footer><?php echo $row['price'] ?></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Total Copy </p>
									<footer><?php echo $row['total_copy'] ?></footer>
								</blockquote>
							</div>
						
							

							
							
						</div> <!-- end row -->
					</div>	<!-- end tab panel -->					

					<!-- tab one close -->

					<!-- tab 2 start -->

					<div role="tabpanel" class="tab-pane " id="profile">						

						<div class="row">

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Physical Form </p>
									<footer></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p>
										<i class="fa  fa-circle-o">
										</i> 
										Editor									</p>
									<footer></footer>
								</blockquote>
							</div>

							

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p>
									<i class="fa fa-circle-o">
									</i> 
									Total Pages</p>
									<footer>0									</footer>
								</blockquote>
							</div>


							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Size</p>
									<footer>Medium</footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Series</p>
									<footer></footer>
								</blockquote>
							</div>							

							<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
								<blockquote>
									<p>
										<i class="fa fa-circle-o">
										</i> 
										Price										</p>
										<footer>
																					</footer>
									</blockquote>
								</div>
								<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
									<blockquote>
										<p>
											<i class="fa fa-circle-o">
											</i> 
											Location</p>
											<footer>
												stack 2 nd floor											</footer>
										</blockquote>
								</div>

								<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p>
										<i class="fa  fa-th-circle-o">
										</i> 
										Clue Page									</p>
									<footer></footer>
								</blockquote>
							</div>

					

							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<blockquote>
									<p><i class="fa fa-circle-o"></i> Publisher</p>
									<footer></footer>
								</blockquote>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
								<blockquote>
									<p>
										<i class="fa fa-circle-o">
										</i> 
										Publication Year - Place</p>
										<footer>0000 - </footer>
								</blockquote>
							</div>
													
							
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<blockquote>
									<p>
									<i class="fa fa-circle-o">
									</i> 
									Source of Book</p>
									<footer>									</footer>
								</blockquote>
							</div>
							</div> 

					</div>
					<!-- tab 2 closes -->
				</div> <!-- end tab content -->
			</div>
		</div>
	</div>
</div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    
   
  <?php
  include_once('footer.php');
  ?>

	<script type="text/javascript">
	$(document).ready(function(){
	
     var fade= $("#fade").text();
	 if(fade != ''){
		$("#fade").fadeOut(1500);
	  window.setTimeout(function() {
    window.location.href = 'showpost.php';
}, 1500);
	 }
	 
});
	</script>
</body>

</html>
