<?php
 include('../include/config.php');
 include('session.php');

 if(isset($_GET['book'])){
	 $ID=$_GET['book'];
	 $del=mysqli_query($conn,"DELETE FROM books WHERE id='$ID' LIMIT 1 ");
	 if($del){
		 $_SESSION['error'] = "book Delete Successfully";

		header("location:books.php");
	 }
	 else{
		  $_SESSION['error'] = "book Not Delete ";

		header("location:books.php");
	 }
 }
