<?php
    include('include/config.php');
	
  include('session.php');
  $book=$_POST['book'];
  $std=$_POST['std'];
  $date=date("Y-m-d");
  
 $sql=mysqli_query($conn,"INSERT INTO bookrequest(book_id, std_id,req_at) VALUES('$book','$std','$date') ");
if($sql){
	echo "Request Successful";
}
else{
	echo "sorry no Request this time";
}

?>