<?php
@ session_start();
	if(!empty($_SESSION["std_admin"]))
	{
	$suname=$_SESSION["std_admin"];
	$session_id=$_SESSION["std_id"];
	}
	else
	{
	header("location:login.php");
	}
	?>