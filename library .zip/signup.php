<?php
include('include/config.php');
if(isset($_POST['reg'])){
	
		$name = $_POST['name'] ;
		$stdid = $_POST['stdid'] ;
		$address = $_POST['address'] ;
		$city = $_POST['city'] ;
		$province = $_POST['province'] ;
		$postal = $_POST['postal'] ;
		$email = $_POST['email'];
		$password = $_POST['password'] ;
		$course = $_POST['course'];
		$gender=$_POST['gender'];
		$website=$_POST['website'];
		$dob=$_POST['dob'];
	
		$sqls=mysqli_query($conn,"INSERT INTO students(name, gender, address, city, postal, province, email, password, birth_date, student_id, website, course) VALUES('$name','$gender','$address','$city','$postal','$province','$email','$password','$dob','$stdid','$website','$course') ");
		
		
		if($sqls){
			$msg=' <div class="alert alert-success">
    <strong>Success! </strong> Registration Successfully.
  <a href="login.php">Login Here </a> </div>';
		}
		else{
			$msg=' <div class="alert alert-danger">
    <strong>Sorry!</strong> Registration Not Success .
  </div>';
		}

      
}

?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
    <title>Library Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href="css/clean-blog.min.css" rel="stylesheet">
 <link href="css/datepicker3.css" rel="stylesheet"> 
  </head>

  <body>

  <?php
  @ session_start();
  include('nav.php');
  ?>
    <!-- Page Header -->
    <header class="masthead" style="background-image: url('img/home-bg.jpg')">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="site-heading">
              <h1>LMS</h1>
              <span class="subheading">Registration</span>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Main Content -->
<div class="container" style="background-color:#e2e2e2;padding:20px;">
<br>
					<?php  
				if(isset($msg))
			{
			echo $msg;
			}
				?>
    <h1 class="well text-center">Registration Form</h1>
	<br>
	<div class="col-md-10  well">
	<div class="row">
				<form method="post">
					<div class="col-sm-12 " >
						<div class="row">
							<div class="col-sm-6 form-group">
								<label> Name</label>
								<input type="text" placeholder="Enter Name Here.." class="form-control" name="name" required>
							</div>
							<div class="col-sm-6 form-group">
								<label>Student ID</label>
								<input type="text" placeholder="Enter Student ID Here.." class="form-control" name="stdid" required>
							</div>
						</div>					
						<div class="form-group">
							<label>Address</label>
							<textarea placeholder="Enter Address Here.." name="address" rows="3" class="form-control"></textarea>
						</div>	
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>City</label>
								<input type="text" name="city" placeholder="Enter City Name Here.." class="form-control" required>
							</div>	
							<div class="col-sm-4 form-group">
								<label>Province</label>
								<input type="text" name="province" placeholder="Enter Province  Here.." class="form-control">
							</div>	
							<div class="col-sm-4 form-group">
								<label>Postal Code</label>
								<input type="text" name="postal" placeholder="Enter Postal Code Here.." class="form-control">
							</div>		
						</div>
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Email Address</label>
						<input type="text" name="email" placeholder="Enter Email Address Here.." class="form-control" required>
							</div>		
							<div class="col-sm-6 form-group">
								<label>Password</label>
						<input type="password" name="password" placeholder="Enter Password Here.." class="form-control" required>
							</div>	
						</div>						
					<div class="form-group">
						<label>Course</label>
						<input type="text" name="course" placeholder="Enter Phone Number Here.." class="form-control" required>
					</div>		
					<div class="form-group">
						
						<label>Gender</label>
								<select  class="form-control"  name="gender" required>
									<option value="male">Male</option>
									<option value="female">Female</option>
									
								  </select>
					</div>	
					<div class="row">
							<div class="col-sm-6 form-group">
								<label>Dob</label>
						<input type="text" name="dob" placeholder="Enter Birth date Here.." id="dob" class="form-control" required>
							</div>		
							<div class="col-sm-6 form-group">
								<label>Website</label>
						<input type="url" name="website" placeholder="Enter Website Here.." class="form-control" >
							</div>	
						</div>	
					<input type="submit"  name="reg" class="btn btn-info" value="Submit">					
					</div>
				</form> 
				</div>
	</div>
	</div>
	
	 <footer id="footerz">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <ul class="list-inline text-center">
              <li class="list-inline-item">
                <a href="#">
                  <span class="fa-stack fa-lg">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-twitter fa-stack-1x fa-inverse"></i>
                  </span>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <span class="fa-stack fa-lg">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-facebook fa-stack-1x fa-inverse"></i>
                  </span>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <span class="fa-stack fa-lg">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-github fa-stack-1x fa-inverse"></i>
                  </span>
                </a>
              </li>
            </ul>
            <p class="copyright text-muted">Copyright Baljit Kaur &copy; Library Management System</p>
          </div>
        </div>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

 
<script src="js/bootstrap-datepicker.min.js"></script> 
<script>

	 $('#dob').datepicker({
			  format: "yyyy-mm-dd",
					autoclose: true
     
    });
	
	
	
			</script>
  </body>

</html>

	 