<?php
include('include/config.php');
if(isset($_POST['login'])){
	
$user=$_POST['email'];	
$pwd=$_POST['password'];

$sqls=mysqli_query($conn,"SELECT * FROM students WHERE student_id='$user' AND password='$pwd' ");

$r=mysqli_fetch_assoc($sqls);

if(($r['student_id']==$user) && ($r['password']==$pwd) )
{
	
	@ session_start();
	$_SESSION["std_admin"]=$user;
	$_SESSION["std_id"]=$r['id'];
	
	header("location: index.php");
}

	else {
			$msg='<div class="alert alert-danger">
  <strong>Wrong!</strong> student id Or Password.
</div>';
	}   
      
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>LMS | Login </title>

    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

	<link href="css/login.css" rel="stylesheet">
    <link href="css/clean-blog.min.css" rel="stylesheet">
  </head>
  <body>
   
  <?php
  @ session_start();
  include('nav.php');
  ?>

<div class="container">
  
  <div class="row" id="pwd-container">
    <div class="col-md-4"></div>
    
    <div class="col-md-4">
      <section class="login-form">
        <form method="post"  role="login">
         <h3 class="text-center"> Student Login</h3>
          <input type="text" name="email" placeholder="Student ID" required class="form-control input-lg"  />
          
          <input type="password" class="form-control input-lg" id="password" placeholder="Password" name="password" required="" />
          
          
   
          
          
          <input type="submit" name="login" class="btn  btn-primary btn-block" value="Sign in">
         <a href="signup.php" class="text-left"> Register Here</a>
		
        </form>
          <br>
	  	<?php  
				if(isset($msg))
			{
			echo $msg;
			}
				?>
	  
       
      </section>  
      </div>
      
   
      

  </div>
  
   
  
  
</div>
	    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>