<?php
@ session_start();
	if(!empty($_SESSION["lms_admin"]))
	{
	$suname=$_SESSION["lms_admin"];
	}
	else
	{
	header("location:login.php");
	}
	?>