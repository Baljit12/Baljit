<?php
 include('../include/config.php');

if (isset($_POST['submit'])) 
{
$user=mysqli_real_escape_string($conn, $_POST['username']);	
$user=strtolower($user);
$pwd=mysqli_real_escape_string($conn, $_POST['password']);

$sqls=mysqli_query($conn,"SELECT * FROM admin WHERE username='$user' AND password='$pwd' ");

$r=mysqli_fetch_assoc($sqls);

if(($r['username']==$user) && ($r['password']==$pwd) )
{
	//setcookie('googtrans', '/en/hi', time()+3600);
	@ session_start();
	$_SESSION["lms_admin"]=$user;
	header("location: index.php");
}

	else {
			$msg='<div class="alert alert-danger">
  <strong>Wrong!</strong> Username Or Password.
</div>';
	}   
        

}


?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin Login</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <link href="css/sb-admin-2.css" rel="stylesheet">

  

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Sign In</h3>
                    </div>
                    <div class="panel-body">
                        <form  method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Username" name="username" type="text" autofocus required >
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" required >
                                </div>
                              
                                <!-- Change this to a button or input when using this as a form -->
                                <input type="submit" name="submit" class="btn btn-lg btn-success btn-block" value="Login">
                            </fieldset>
                        </form>
                    </div>
                </div>
				<?php  
				if(isset($msg))
			{
			echo $msg;
			}
				?>
            </div>
        </div>
    </div>

  

</body>

</html>
